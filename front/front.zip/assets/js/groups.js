window.onclick = function(event) {
    if ((event.target == document.getElementById('group__modal')) || (event.target == document.getElementById('contacts__modal'))) {
        document.getElementById('group__modal').style.display = "none";
        document.getElementById('contacts__modal').style.display = "none";

    }
}
async function getGroups() {
    return axios.get('http://localhost:8084/contact/group/').then(responce => (responce = responce.data))
}
async function groupsCreateRequest(title) {
    axios.post('http://localhost:8084/contact/group/', { title: title })
}
async function getGroupEmails(id) {
    return axios.get('http://localhost:8084/contact/?groupId=' + id).then(responce => (responce = responce.data))
}
async function getContactByEmail(email) {
    return axios.get('http://localhost:8084/contact/?email=' + email).then(responce => (responce = responce.data))
}
async function getContactById(id) {
    return axios.get('http://localhost:8084/contact/?id=' + id).then(responce => (responce = responce.data))
}
async function deleteGroupContact(groupId, id) {
    var groups = []
    var data = await getContactById(id)
    for (let i = 0; i < data[0].groups.length; i++) {
        if (data[0].groups[i].id == groupId) {
            i++;
        } else {
            groups.push(data[0].groups[i])
        }
    }
    axios.put('http://localhost:8084/contact/', { id: id, email: data[0].email, groups: groups })
}

function createGroup() {
    var title = document.getElementById('group__title').value
    groupsCreateRequest(title)
    showGroups()
    document.getElementById('group__modal').style.display = "none"
}

function showGroupsModal() {
    document.getElementById('group__modal').style.display = "block";
}

async function showEmails(groupId) {
    document.getElementsByClassName('section__third')[0].style.display = "block"
    document.getElementsByClassName('section__third')[0].innerHTML = '<ul class="section__list" id="list3"></ul>'
    var sectionEmails = document.getElementById('list3')
    var emails = await getGroupEmails(groupId)
    console.log(groupId)
    for (let i = 0; i < emails.length; i++) {
        var e = emails[i].email
        sectionEmails.innerHTML += '<li class="section__edit"><input disabled type="text" class="section__input" value="' + e + '"><span class="icon_delete" onclick="deleteGroupContact(' + groupId + ',' + emails[i].id + ')"></span></li>'
    }
}
async function showGroups() {
    document.getElementsByClassName('section__second')[0].style.display = "block"
    document.getElementsByClassName('section__second')[0].innerHTML = '<div class="button" onclick="showGroupsModal()">Добавить</div><ul class="section__list" id="list2"></ul>'
    var sectionGroups = document.getElementById('list2')
    sectionGroups.innerHTML = ''
    var groups = await getGroups()
    for (let i = 0; i < groups.length; i++) {
        sectionGroups.innerHTML += '<li class="section__link" onclick="showEmails(' + groups[i].id + ')"><span class="link__name">Группа:' + groups[i].title + ' </span><span class="link__description">Описание</span></li>'
    }
}