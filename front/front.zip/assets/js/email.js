window.onclick = function(event) {
    if (event.target == document.getElementById('add__modal')) {
        document.getElementById('add__modal').style.display = "none";
        document.getElementById('groups__contact').innerHTML = ''
    }
}
async function getContactByGroup(id) {
    return axios.get('http://localhost:8084/contact/?groupId=' + id).then(response => (response = response.data))
}
async function getGroups() {
    return axios.get('http://localhost:8084/contact/group/').then(responce => (responce = responce.data))
}

function inputClickHandler() {
    document.getElementById("file-input").click();
}

//var fileType = null;
//var files = [];
var contentItems = [];//last

function filePost() {
    var input = document.getElementById('file-input');
    var container = document.getElementById('files');
    for (var i = 0; i < input.files.length; i++) {

        var file = input.files[i];
        var contentType = file.type;
        var  fileName = file.name;

        //var type = file.type
        //fileType = type;
        var reader = new FileReader();
        reader.onload = function() {

            var res = this.result;
            var data = res.replace(/.*base64,/, '');
            contentItems.push(
                {
                    contentType: contentType,
                    fileName: fileName,
                    content: data
                }
            )
            // files = this.result
            // console.log(files)
            //     //files.push({ id: i, contentType: type, content: array })
        }
        reader.readAsDataURL(file)
        container.innerHTML += /*'<div class="file-show">'*/ '<div class="file-show" id="' + fileName + '">' +
            file.name + '<span class="close" onclick="deleteFile(\'' + fileName + '\')"></span></div>'
    }
}
async function showAddModal() {
    var modal = document.getElementById('add__modal')
    var groups = await getGroups()
    for (let i = 0; i < groups.length; i++) {
        document.getElementById('groups__contact').innerHTML += '<option value="' + groups[i].id + '">' + groups[i].title + '</option>'
    }
    console.log(groups)
    modal.style.display = "block";
}
async function addFromGroup() {
    var input = document.getElementById('toEmail')
    var e = document.getElementById("groups__contact");
    var a = await getContactByGroup(e.value)
    for (let i = 0; i < a.length; i++) {
        input.value += a[i].email + ','
    }
}

function deleteFile(fileName) {
    for (var i = 0; i < contentItems.length; i++) {
        if (contentItems[i].fileName == fileName) {
            contentItems.splice(i, 1)
            document.getElementById(fileName).remove();
            break;
        }
    }
}
// function deleteFile(id) {
//     for (var i = 0; i < files.length; i++) {
//         if (files[i].id == id) {
//             files.splice(i, 1)
//             break;
//         }
//     }
// }

function sendmail() {
    var subject = document.getElementById('subject').value;
    var toEmail = document.getElementById('toEmail').value;
    var text = document.getElementById('text').value;

    var mailJson = null;
    if (contentItems.length != 0) {

        if (text != '') contentItems.push({ contentType: 'text/plain', content: text });

        var mail = {
            to: toEmail,
            subject: subject,
            emailContent: {
                contentType: 'multipart/mixed',
                content: contentItems
            }
        }

        mailJson = JSON.stringify(mail);
        contentItems.pop();

    } else {
        //если у нас пустое сообщение и нет прикрепленных файло, то мы ничего не отправляем
        if (text == '') {
            alert('Пустое сообщение');
            return;
        }

        var mail = {
            to: toEmail,
            subject: subject,
            emailContent: {
                contentType: 'multipart/mixed',
                content: [
                    {
                        contentType: 'text/plain',
                        content: text
                    }
                ]
            }
        }
        mailJson = JSON.stringify(mail);
    }

    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'http://localhost:8084/email/', true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.send(mailJson);
    // var subject = document.getElementById('subject').value;
    // var toEmail = document.getElementById('toEmail').value;
    // var text = document.getElementById('text').value;
    //
    // var content = null;
    // var contentType = null;
    // if (files.length != 0) {
    //     contentType = 'multipart/mixed'
    //         //files.unshift({ contentType: 'text/plain', content: text })
    //
    //     content = {
    //         to: toEmail,
    //         subject: subject,
    //         emailContent: {
    //             contentType: contentType,
    //             content: [{
    //                     contentType: 'text/plain',
    //                     content: text
    //                 },
    //                 {
    //                     contentType: fileType,
    //                     content: files
    //                 }
    //             ]
    //         }
    //     }
    // } else {
    //     contentType = 'text/plain'
    //
    //     content = {
    //         to: toEmail,
    //         subject: subject,
    //         emailContent: {
    //             contentType: contentType,
    //             content: text
    //         }
    //     }
    // }
    //
    // var json = JSON.stringify(content);
    // console.log(json);
    //
    // var xhr = new XMLHttpRequest();
    // xhr.open('POST', 'http://localhost:8084/email/', true);
    // xhr.setRequestHeader('Content-Type', 'application/json');
    // xhr.send(json);
}
