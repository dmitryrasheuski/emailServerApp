async function contactCreateRequest(email, groups) {
    axios.post('http://localhost:8084/contact/', { email: email, groups: groups })
}
async function getContacts() {
    return axios.get('http://localhost:8084/contact/').then(response => (response = response.data))
}
async function deleteСontact(id) {
    return axios.delete('http://localhost:8084/contact/', { data: { id: id } }).then(responce => (responce = responce.data))
}

async function showContactsModal() {
    var modal = document.getElementById('contacts__modal')
    var groups = await getGroups()
    for (let i = 0; i < groups.length; i++) {
        console.log('1')
        document.getElementById('groups__contact').innerHTML += '<option value="' + groups[i].id + '">' + groups[i].title + '</option>'
    }
    console.log(groups)
    modal.style.display = "block";
}

async function editContact(id) {
    var input = document.getElementById('contact' + id)
    var select = document.getElementById('select' + id)
    if (input.disabled == true) {
        input.disabled = false
        select.disabled = false
    } else {
        input.disabled = true
        select.disabled = true
        var e = document.getElementById("select" + id);
        var selectedGroups = []
        var groups = await getGroups()
        for (let j = 0; j < await groups.length; j++) {
            for (let i = 0; i < e.length; i++) {
                currentOption = e[i];
                console.log(currentOption)
                if ((currentOption.selected == true) && (currentOption.value == groups[j].id)) {
                    console.log(groups[j])
                    selectedGroups.push(groups[j])
                }
            }
        }
        console.log(selectedGroups)
        axios.put('http://localhost:8084/contact/', { id: id, email: input.value, groups: selectedGroups })
    }
}
async function createContact() {
    var e = document.getElementById("groups__contact");
    var groups = []
    for (let i = 0; i < e.length; i++) {
        currentOption = e[i];
        if (currentOption.selected == true) {
            groups.push({ id: currentOption.value })
        }
    }
    console.log(groups)
    var email = document.getElementById('contact__email').value
    contactCreateRequest(email, groups)
}

async function showContacts() {
    document.getElementsByClassName('section__second')[0].style.display = "block"
    document.getElementsByClassName('section__second')[0].innerHTML = '<div class="button mb-2" onclick="showContactsModal()">Добавить</div><input type="text" placeholder="Поиск..." id="search1" class="search__contacts mb-2" onchange="searchContacts()"><ul class="section__list" id="list2"></ul>'
    var sectionContacts = document.getElementById('list2')
    sectionContacts.innerHTML = ''
    document.getElementsByClassName('section__third')[0].style.display = "none"
    var contacts = await getContacts()
    for (let i = 0; i < contacts.length; i++) {
        var x = document.createElement("SELECT");
        x.multiple = true;
        x.classList.add('w-100', 'mb-2')
        x.setAttribute('id', 'select' + contacts[i].id)
        x.setAttribute('disabled', 'true')
        var selectedGroups = await getContactByEmail(contacts[i].email)
        var groups = await getGroups()
        for (let j = 0; j < groups.length; j++) {
            var option = document.createElement('option');
            option.setAttribute('value', groups[j].id)
            option.innerHTML = groups[j].title
            for (let k = 0; k < selectedGroups[0].groups.length; k++) {
                if (groups[j].id == selectedGroups[0].groups[k].id) {
                    option.setAttribute('selected', 'true')
                }
            }
            x.innerHTML += option.outerHTML
        }
        sectionContacts.innerHTML += '<li class="section__edit d-block"><div class="row mb-0"><input disabled id="contact' + contacts[i].id + '"type="text" class="section__input" value="' + contacts[i].email + '"><span class="icon_edit" onclick="editContact(' + contacts[i].id + ')"></span><span class="icon_delete" onclick="deleteСontact(' + contacts[i].id + ')"></span></div>' + x.outerHTML + '</li>'
    }
}

async function searchContacts() {
    var contacts = await getContacts()
    var input = document.getElementById('search1')
    var sectionContacts = document.getElementById('list2')
    var matches = 0
    if (input.value == '' || input.value == ' ') {
        sectionContacts.innerHTML = ''
        showContacts()
            // for (let i = 0; i < contacts.length; i++) {
            //     sectionContacts.innerHTML += '<li class="section__edit"><input disabled type="text" class="section__input" value="' + contacts[i].email + '"><span class="icon_delete"></span></li>'
            // }
    } else {
        for (let i = 0; i < contacts.length; i++) {
            if ((input.value != '' || input.value != ' ') && matches == 0) {
                sectionContacts.innerHTML = '<li class="section__edit"><input disabled type="text" class="section__input" value="Совпадений не найдено"></li>'
            }
            if (contacts[i].email.includes(input.value)) {
                matches++;
                if (matches == 1) {
                    var x = document.createElement("SELECT");
                    x.multiple = true;
                    x.classList.add('w-100', 'mb-2')
                    x.setAttribute('id', 'select' + contacts[i].id)
                    x.setAttribute('disabled', 'true')
                    var selectedGroups = await getContactByEmail(contacts[i].email)
                    var groups = await getGroups()
                    for (let j = 0; j < groups.length; j++) {
                        var option = document.createElement('option');
                        option.setAttribute('value', groups[j].id)
                        option.innerHTML = groups[j].title
                        for (let k = 0; k < selectedGroups[0].groups.length; k++) {
                            if (groups[j].id == selectedGroups[0].groups[k].id) {
                                option.setAttribute('selected', 'true')
                            }
                        }
                        x.innerHTML += option.outerHTML
                    }
                    sectionContacts.innerHTML = '<li class="section__edit d-block"><div class="row mb-0"><input disabled id="contact' + contacts[i].id + '"type="text" class="section__input" value="' + contacts[i].email + '"><span class="icon_edit" onclick="editContact(' + contacts[i].id + ')"></span><span class="icon_delete" onclick="deleteСontact(' + contacts[i].id + ')"></span></div>' + x.outerHTML + '</li>'
                } else {
                    var x = document.createElement("SELECT");
                    x.multiple = true;
                    x.classList.add('w-100', 'mb-2')
                    x.setAttribute('id', 'select' + contacts[i].id)
                    x.setAttribute('disabled', 'true')
                    var selectedGroups = await getContactByEmail(contacts[i].email)
                    var groups = await getGroups()
                    for (let j = 0; j < groups.length; j++) {
                        var option = document.createElement('option');
                        option.setAttribute('value', groups[j].id)
                        option.innerHTML = groups[j].title
                        for (let k = 0; k < selectedGroups[0].groups.length; k++) {
                            if (groups[j].id == selectedGroups[0].groups[k].id) {
                                option.setAttribute('selected', 'true')
                            }
                        }
                        x.innerHTML += option.outerHTML
                    }
                    sectionContacts.innerHTML += '<li class="section__edit d-block"><div class="row mb-0"><input disabled id="contact' + contacts[i].id + '"type="text" class="section__input" value="' + contacts[i].email + '"><span class="icon_edit" onclick="editContact(' + contacts[i].id + ')"></span><span class="icon_delete" onclick="deleteСontact(' + contacts[i].id + ')"></span></div>' + x.outerHTML + '</li>'
                }
            }
        }
    }
}